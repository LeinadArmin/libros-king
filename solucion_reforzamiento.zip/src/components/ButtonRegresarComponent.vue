<template>

    <div class="text-end container mb-5">
      <router-link to="/" class="btn text-end">Regresar</router-link>
    </div>
    
</template>
  
<script>

export default {
name: 'ButtonRegresarComponent',
};
</script>

<style>
.btn {
background-color: #00ADB5;
color: #EEEEEE
} 
</style>

  